# . pwm0_off.sh
omega2-ctrl gpiomux set pwm0 gpio
omega2-ctrl gpiomux set pwm1 gpio
#fast-gpio set input 18
#fast-gpio set input 19
